from application import app, db
from flask import render_template, request, json, Response, redirect, flash, url_for, session

from application.forms import LoginForm, RegisterForm
from application.models import User, Students
import pandas as pd


@app.route("/")
@app.route("/index")
@app.route("/home")
def index():
    return render_template("index.html", index=True)


@app.route("/login", methods=['GET', 'POST'])
def login():
    if session.get('username'):
        return redirect(url_for('index'))

    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data

        user = User.objects(email=email).first()
        if user and user.get_password(password):
            flash(f"{user.email}, you are successfully logged in!", "success")
            session['user_id'] = user.user_id
            session['username'] = user.email
            return redirect("/index")
        else:
            flash("Sorry, something went wrong.", "danger")
    return render_template("login.html", title="Login", form=form, login=True)


@app.route("/logout")
def logout():
    session['user_id'] = False
    session.pop('username', None)
    return redirect(url_for('index'))


@app.route("/campus")
def campus():
    classes = Students.objects.all()
    return render_template("campus.html", courseData=classes, courses=True)


@app.route("/register", methods=['POST', 'GET'])
def register():
    if session.get('username'):
        return redirect(url_for('index'))
    form = RegisterForm()
    if form.validate_on_submit():
        user_id = User.objects.count()
        user_id += 1
        email = form.email.data
        password = form.password.data
        user = User(user_id=user_id, email=email)
        user.set_password(password)
        user.save()
        flash("You are successfully registered!", "success")
        return redirect(url_for('index'))
    return render_template("register.html", title="Register", form=form, register=True)


@app.route("/user")
def user():
    #User(user_id=1, email="christian@supinfo.com", password="abc1234").save()
    #User(user_id=2, email="mary.jane@supinfo.com", password="password123").save()
    users = User.objects.all()
    return render_template("user.html", users=users)
