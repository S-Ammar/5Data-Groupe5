import flask
from application import db
from werkzeug.security import generate_password_hash, check_password_hash
import pandas


class User(db.Document):
    user_id = db.IntField(unique=True)
    first_name = db.StringField(max_length=50)
    last_name = db.StringField(max_length=50)
    email = db.StringField(max_length=30)
    password = db.StringField()

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def get_password(self, password):
        return check_password_hash(self.password, password)


"""class Campus(db.Document):
    campus_id = db.IntField(unique=True)
    id = db.IntField()
    campusName = db.StringField(max_length=100)
    students = db.IntField()
    jPOperYear = db.IntField()
    nbDropOuts = db.IntField()
    nbCollaborators = db.IntField()
    currentStudents = db.IntField()"""

class Students(db.Document):

    id = db.IntField(unique=True)
    study_year = db.StringField(max_length=100)
    campus = db.StringField(max_length=100)
    cursus = db.StringField(max_length=100)
    attendance = db.StringField(max_length=100)
    gender = db.StringField(max_length=100)
    score = db.IntField()
    status = db.StringField(max_length=100)
    entry_level = db.StringField(max_length=100)
    join_year = db.IntField()
    internship = db.StringField(max_length=10)